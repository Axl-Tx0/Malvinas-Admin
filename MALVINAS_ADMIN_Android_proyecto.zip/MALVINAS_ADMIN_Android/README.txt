MALVINAS ADMIN - Proyecto Android

Este ZIP contiene el proyecto fuente Android y una automatización para compilar el APK en GitHub Actions, sin instalar Android Studio en tu computadora.

OPCION A - COMPILAR EN LA NUBE (requiere cuenta gratuita de GitHub y subir el proyecto):
1. Entra a https://github.com/ y crea/inicia sesión en tu cuenta.
2. Crea un repositorio nuevo. Puedes llamarlo MALVINAS-ADMIN. Déjalo vacío.
3. Descomprime este ZIP en una computadora y sube TODO el contenido de la carpeta MALVINAS_ADMIN_Android al repositorio, incluyendo la carpeta oculta .github.
4. En GitHub abre la pestaña Actions y selecciona "Build MALVINAS ADMIN APK".
5. Pulsa "Run workflow" y confirma con el botón verde.
6. Cuando termine correctamente, abre la ejecución y descarga el artefacto "MALVINAS-ADMIN-APK". Dentro estará app-debug.apk.
7. Pasa el APK a tu Android, ábrelo y autoriza la instalación desde esa fuente si Android lo solicita.

OPCION B - ANDROID STUDIO:
1. Abre la carpeta MALVINAS_ADMIN_Android en Android Studio.
2. Espera la sincronización de Gradle y la instalación del SDK 35 si lo solicita.
3. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
4. El APK estará en app/build/outputs/apk/debug/app-debug.apk.

IMPORTANTE:
- Este proyecto es una primera versión funcional de administración. Los datos se guardan localmente en el almacenamiento del WebView del teléfono.
- Exporta copias JSON regularmente. Si borras los datos de la aplicación o la desinstalas, podrías perder los registros locales.
- La sección VPS es un registro administrativo; no comprueba conectividad ni controla servidores automáticamente.
- No guardes contraseñas SSH/VPS sensibles en la app.
- El APK generado por este flujo es de depuración (debug), suficiente para instalar y probar; no es una publicación firmada para Play Store.
